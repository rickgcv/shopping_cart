sap.ui.define([
	"./BaseController"
], function (BaseController) {
	"use strict";

	return BaseController.extend("socreation_test.SO_Create.controller.DetailObjectNotFound", {});
});
